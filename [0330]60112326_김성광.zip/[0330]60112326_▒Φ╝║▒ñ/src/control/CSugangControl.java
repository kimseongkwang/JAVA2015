package control;

import entity.CSugang;


public class CSugangControl {
	
	public CSugang shinchung(CSugang sugang){
		return sugang;
	}

}
