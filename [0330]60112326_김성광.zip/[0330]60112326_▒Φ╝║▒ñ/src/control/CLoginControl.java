package control;

import entity.CMember;

public class CLoginControl {
	private CMember member;
	
	public CMember login(CMember member) {
		// TODO Auto-generated method stub
		
		this.member = member;//�������ε� ��
		return this.member;
	}

}
