package view;

import entity.CGwamok;

public class CGwamokView {

	public CGwamok getGwamok() {
		// TODO Auto-generated method stub
		CGwamok gwamok =new CGwamok();
		gwamok.setID(21);
		gwamok.setName("�ڹ����α׷���");
		gwamok.setHakjeom(3);
		return gwamok;
		
	}

}
