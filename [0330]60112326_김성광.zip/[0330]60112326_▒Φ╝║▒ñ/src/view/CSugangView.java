package view;

import entity.CSugang;

public class CSugangView {

	public CSugang shinchung(){
		CSugang sugang = new CSugang();
		
		sugang.setGangjwaID(50);
		sugang.setGangjwaname("A��");
		
		return sugang;
	}
	
}
