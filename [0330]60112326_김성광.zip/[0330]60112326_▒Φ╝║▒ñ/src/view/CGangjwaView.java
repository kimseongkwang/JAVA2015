package view;

import entity.CGangjwa;

public class CGangjwaView {

	public CGangjwa getGangjwa() {
		// TODO Auto-generated method stub
		CGangjwa  gangjwa =new CGangjwa();
		gangjwa.setID(50);
		gangjwa.setName("A��");
		gangjwa.setGwamokID(21);
	//	gangjwa.setGyosuID(gyosuID);
		return gangjwa;
	}

}
